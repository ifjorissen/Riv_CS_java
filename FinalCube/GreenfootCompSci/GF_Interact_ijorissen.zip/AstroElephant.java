import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AstroElephant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AstroElephant  extends World
{
    final int burgers = 3; //there always needs to be 3 burgers, or the elephant will starve
    /**
     * Constructor for objects of class AstroElephant.
     * 
     */
    public AstroElephant()
    {    
        // Create a new world with 20x20 cells with a cell size of 10x10 pixels.
        super(50, 50, 10);
        populate();
        //  setBackground("space1.png");
    }

    public void populate ()
    {
        elephant dumbo = new elephant(); //add an elephant
        addObject(dumbo,0, 0);

        ninjaBurger ninja = new ninjaBurger(); //add random burgers
        ninja.setImage("ninjaBurger.jpg");
        addObject(ninja, 5, 12);

        ninjaBurger ninja2 = new ninjaBurger();
        ninja2.setImage("ninjaBurger.jpg");
        addObject(ninja2, 40, 25);
        
        ninjaBurger ninja3 = new ninjaBurger();
        ninja3.setImage("ninjaBurger.jpg");
        addObject(ninja3, 20, 40);
        
        replenish(); //keeps burger count at 3
    }
    public void replenish()
    {
        if(getObjects(ninjaBurger.class).size() < burgers)
        {
            ninjaBurger replace = new ninjaBurger();
            replace.setImage("ninjaBurger.jpg");
            addObject(replace, (int)Math.random()*50, (int)Math.random()*50);
        }
    }
}
