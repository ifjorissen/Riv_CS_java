import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion  extends Actor
{
    /**
     * Act - do whatever the Explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    final int expRadius = 15; //set explosion radius
    public Explosion () 
    {
        // Add your action code here.
    }    
    public void act()
    {
        explode();
    }

    public void explode () //initiates an explosion
    {
        List <ninjaBurger> objects = getObjectsInRange(15, ninjaBurger.class);
        ninjaBurger essplode;
        for (int i = 0; i<objects.size(); i++)
        { 
            essplode = objects.get(i);
            essplode.setLocation(getX()+expRadius, getY()+expRadius);
        }
    }
}
