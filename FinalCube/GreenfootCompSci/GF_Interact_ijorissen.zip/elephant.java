import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class elephant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class elephant  extends Actor
//dimensions of world
{
    final int width = 50; 
    final int height = 50;
    /**
     * Act - do whatever the elephant wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public elephant()
    {
    }

    public void act() 
    {
        // Add your action code here.
        if (foundBurger())
        {
            eatBurger();
        }
        else move();
    }    

    public boolean foundBurger()
    {
        Actor ninjaBurger = getOneObjectAtOffset(0, 0, ninjaBurger.class);
        if (ninjaBurger != null)
        {
            ninjaBurger.setImage("hamburger.png");
            return true;
        }
        else return false;
    }

    public void eatBurger()
    {
        Actor ninjaBurger = getOneObjectAtOffset(0, 0, ninjaBurger.class);
        if (ninjaBurger != null)
        {
            getWorld().removeObject(ninjaBurger);
        }
    }

    public void move()
    {
        // setLocation(getX()+1, getY()+1);
        setRotation(getRotation()+10);
        int locationX = (int)((Math.random()*6)-3)%50;
        int locationY = (int)((Math.random()*6)-3)%50;
        setLocation(getX() + locationX, getY() + locationY);
        if (getX() == width-5 ||  getY() == width-5)
        { 
            Explosion explode = new Explosion();
            getWorld().addObject(explode, getX(), getY());
            explode.explode();
            setLocation((width/2), (height/2));
        }
    }
}
