import java.awt.*;
/**
 * Write a description of class Cube here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cube  
{
    /*#
     * Cube array: A 3-Dimensional array of cubelets
     * How are the cubelets arranged?
     * An array based on cubelet type?
     * By layer (bottom, middle, top)?
     */
    /**
     * Locational array of cube
     */
    Color [] col;
    private Cubelet [] [] [] cube;
    CubeC cC1, cC2, cC3, cC4, cC5, cC6, cC7, cC8; //8 corner pieces
    CubeE cE1, cE2, cE3, cE4, cE5, cE6, cE7, cE8, cE9, cE10, cE11, cE12; //12 edges
    CubeM cM1, cM2, cM3, cM4, cM5, cM6; //6 center pieces
    Color yell = Color.yellow;
    /**
     * Constructor for objects of class Cube
     */
    public Cube()
    {
        Cubelet Cube [][][] =  {
                {
                    {cC1, cE1, cC2}, 
                    {cE2, cM1, cE3}, 
                    {cC3, cE4, cC4}
                },//one face          
                {
                    {cE5, cM2, cE6},
                    {cM3, null, cM4}, 
                    {cE7, cM5, cE8}
                }, //middle "face" or row
                { 
                    {cC5, cE9, cC6},
                    {cE10, cM6, cE11},
                    {cC7, cE12, cC8}//back face 

                }
            };
        cube = Cube;
        setLocationsColors();
    }

    //Set new locations of cubelets based on location in array
    private void setLocationsColors()
    {
        for (int i = 0; i < cube.length; i++) //iterate through outermost aspect of array
        {
            for (int j = 0; i < cube[0].length; j++)
            {
                for (int k = 0; k< cube[0][0].length; k++) //iterate through innermost aspect of array
                {
                    cube[i][j][k].setLocation(i,j,k);
                    if (i == 0)
                    {
                        cube[i][j][k].setColor(Color.yellow);
                        if (j == 0)
                            cube[i][j][k].setColor(Color.red);
                        if (j == 2)
                            cube[i][j][k].setColor(Color.orange);
                        if (k == 0)
                            cube[i][j][k].setColor(Color.blue);
                        if (k == 2)
                            cube[i][j][k].setColor(Color.green);
                    }
                    if (i == 1)
                    {
                        if (j == 0) cube[i][j][k].setColor(Color.red);
                        if (j == 1)
                        {
                            if (k == 0) cube[i][j][k].setColor(Color.blue);
                            if (k == 2) cube[i][j][k].setColor(Color.green);
                        }
                        if (j == 2) cube[i][j][k].setColor(Color.orange);
                    }
                    if (i == 2)
                    {
                        cube[i][j][k].setColor(Color.black);
                        if (j == 0) 
                            cube[i][j][k].setColor(Color.red);
                        if (j == 2)
                            cube[i][j][k].setColor(Color.orange);
                        if (k == 0)
                            cube[i][j][k].setColor(Color.blue);
                        if (k == 2)
                            cube[i][j][k].setColor(Color.green);
                    }
                }
            }
        }
    }

    //returns middle cubelet of the face being looked at

    //Moves face one move counterclockwise
    public void moveCounter()
    {

    }

    //Moves face one move clockwise
    public void moveClock()
    {

    }

    public void M1 () //move m1 face
    {
    }

    public void M2 () //move m2 face
    {
    }

    public void M3 () //move m3 face
    {
    }

    public void M4 () //move m4 face
    {
    }

    public void M5 () //move m5 face
    {
    }

    public void M6 () //move m6 face
    {
    }

    public String toString()
    {
        for (int i = 0; i<cube.length; i++)
        {
            for (int j = 0; j<cube[0].length; j++)
            {
                for (int k = 0; k<cube[0][0].length; k++)
                    System.out.println(cube[i][j][k]);
            }
        }
        return "done";
    }

    //make methods for each "face"
}

